<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/compétences.css">
    <script src="fichier.js" async></script>
    <title>Compétences</title>
</head>
<body>
    


    <div class="flex">
        <div class="txt-titre">Mes Compétences</div>
    

        <div class="vide"></div>
        

        <div class='navbar'>
            <a href="mesProjets.php"><input class="test" type ="button" value="Mes Projets" ></a>
            <a href="index.html"><input class="test" type ="button" value="Accueil" ></a>
            <a href="parcours.html"><input class="test" type ="button" value="Mon Parcours" ></a>
        </div>
        
        <p id="p1"></p>
            <div class="flex2">
                        
                <!-- &nbsp; espace    &ensp; double espace    &emsp; quadruple espace-->
                <div class="txt-accueil">
                    <p>Voici mes compétences,<br>
                    parmis celle-ci, au niveau language,<br>
                    on y retrouve du HTML CSS,<br>
                    JavaScript, PHP, Wordpress...<br>
                    Au niveau Bureautique, on y retrouve :<br>
                    du Powerpoint, Word<br>
                    Photoshop...,<br>
                    Et pour finir, au niveau informatique<br>
                    Du Linux etc.<br>
                    |<br>
                    |<br>
                    V<br>
                    <a href="souspages/competenceApprofondis.php" src="">Tableau de compétences approfondis</a></p>

                    <table id="tableau">
                    
                        <caption >Tableau de compétences</caption>
    
                        <colgroup style="width:200px">
                            <col>
                            <col>
                            <col>
                        </colgroup>
                        
                       
                        
                        <tr> <th>Bureautique</th> <th>Language de programmation</th> <th>Informatique</th> </tr>
                        
                        <tr> <td>PowerPoint </td> <td>Javascript</td> <td>Installation de systèmes d'exploitations</td> </tr>
                        
                        <tr> <td>Excel </td> <td>PHP</td> <td>Windows </td> </tr>
                        
                        <tr> <td>Word </td> <td>HTML/CSS</td> <td>Linux</td> </tr>

                        <tr> <td>Google Drive </td> <td>Wordpress/Prestashop/NicePage</td> <td> </td> </tr>

                        <tr> <td>LibreOffice </td> <td>C++</td> <td></td> </tr>

                        <tr> <td>Photoshop </td> <td>Python</td> <td></td> </tr>

                        <tr> <td> </td> <td>SQL</td> <td></td> </tr>
    
                      </table>

                </div>



            </div>
    </div>


    <div class="time">
        <input type="text" id="time" size="10" />
    </div>

    <div class="p1">
        <p id="p1"></p>
    </div>

<footer>

</footer>



</body>

</html>

<!--point exclamation pour code html direct-->

  <!-- background: linear-gradient(blue, pink); -->
  <!--background-size: 400% 400%; -->
  <!--animation: gradient 15s ease infinite; -->