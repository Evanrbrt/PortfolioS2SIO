<?php
    define("HOST", "localhost");
    define("USER", "vchigot" );
    define("PASS", "valentin");
?>