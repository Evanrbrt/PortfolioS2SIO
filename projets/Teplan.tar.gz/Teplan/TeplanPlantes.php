<html>
    <head>
        <title>TEPLAN</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Teplan.css">
        <script src="footer.js"></script>
    </head>
    <body>
        <div id="MainPage2">
            <h1 id="TitrePlantes">Nos plantes - quelques produits</h1>
            <div Id="Plantes">

            <?php
                include_once("bdListePlante.php");

                $texte = listePlantes();
                echo $texte;
            ?>  
                
            </div>
            
            
        </div>
        
        <footer>
                <?php
                    include_once("bdMagasin.php");

                    $texte = footer();
                    echo $texte;
                ?>  

            <nav class="Lien">
                <a href="TeplanAcceuil.php"><img class="Lien" src="images/planteAcceuil.png"></a>
                <a href="TeplanPlantes.php"><img class="Lien" src="images/plantePlantes.png"></a>
                <a href="TeplanFleurs.php"><img class="Lien" src="images/planteFleurs.png"></a>
                <a href="TeplanAccessoires.php"><img class="Lien" src="images/accessoiresJ.jpg"></a>
            </nav>
        </footer>
    </body>

</html>
