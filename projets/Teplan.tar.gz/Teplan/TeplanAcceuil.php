<html>
    <head>
        <title>TEPLAN</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Teplan.css">
        <script src="footer.js"></script>
    <?php
        include_once("bdMagasin.php");

        $texte = horaireMagasin();
        echo $texte;
    ?>    
    </head>
    <body>

        <div id="MainPage">

            <h1>Ami.e.s des plantes, bienvenu.e.s</h1>

            <p>Vous aimez les plantes, vous voulez marquer une occasion ou aménager <br>
            votre jardin, nous sommes là pour vous aider et vous conseiller.<br><br></p>
            
            <p>Carine, spécialiste des plantes grimpantes est disponible tous les matins<br>
            pour vous donner quelques précieux tuyaux. <img src="images/smiley.png" class="ImageT"><img src="images/smiley.png" class="ImageT"><img src="images/smiley.png" class="ImageT"><br><br></p>

            <p>Proche des circuits courts, nous apportons une grande importance à la<br>
            qualité de nos produits et leur fraicheur ! <img src="images/parapluie.png" class="ImageT"><br><br></p>

            <p>N\'hésitez pas à nous contacter par mail (voir lien contactez-nous) ou par<br>
            téléphone ! <img src="images/telephone.png" class="ImageT"></p>

            <p>Au plaisir de vous voir !</p>
            
            
        </div>
        <div class="cube">
            <p Id="horaires"></p>
            <script>
                
                var horaires = document.getElementById("horaires");
                horaires.innerHTML += "Notre magasin est ouvert<br>du mardi au samedi<br>de " + MardiSamediOuverture + " à " + MardiSamediFermeture + " <br>et le dimanche<br>de " + DimancheOverture + " à " + DimancheFermeture + " <br>";
            </script>
            <p>Pour toute question
                <a href="contact.php">contactez-nous</a> 
            </p>
            

        </div>
        <footer>
     
               
                <?php
                    include_once("bdMagasin.php");

                    $texte = footer();
                    echo $texte;
                ?>  
                
                
                
            <nav class="Lien">
                <a href="TeplanAcceuil.php"><img class="Lien" src="images/planteAcceuil.png"></a>
                <a href="TeplanPlantes.php"><img class="Lien" src="images/plantePlantes.png"></a>
                <a href="TeplanFleurs.php"><img class="Lien" src="images/planteFleurs.png"></a>
                <a href="TeplanAccessoires.php"><img class="Lien" src="images/accessoiresJ.jpg"></a>
            </nav>
        </footer>
    </body>

</html>'
