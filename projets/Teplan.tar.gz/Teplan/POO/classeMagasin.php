<?php


    /*
      class Magasin
      une Magasin se caractérise par un lieu
    */
    class Magasin{
        private string $lieu;
        private string $adresse;
        private string $ville;
        private string $telephone;
        private string $horaires_mardi_samedi_debut;
        private string $horaires_mardi_samedi_fin;
        private string $horaires_dimanche_debut;
        private string $horaires_dimanche_fin;
        private $Fleur=array();


        // constructeur unifié permettant d'initialiser les variables d'instance
        public function __construct(string $p_lieu="", string $p_adresse="", string $p_ville="", string $p_telephone=null, string $p_mardi_samedi_debut=null, string $p_mardi_samedi_fin=null, string $p_dimanche_debut=null, string $p_dimanche_fin=null,array $p_fleur=[]){

          $this->setLieu($p_lieu);
          $this->setAdresse($p_adresse);
          $this->setVille($p_ville);
          $this->setTelephone($p_telephone);
          $this->setHoraires_mardi_samedi_debut($p_mardi_samedi_debut);
          $this->setHoraires_mardi_samedi_fin($p_mardi_samedi_fin);
          $this->setHoraires_dimanche_debut($p_dimanche_debut);
          $this->setHoraires_dimanche_fin($p_dimanche_fin);
          $this->setFleur($p_fleur);

        }
          public function __destruct() {
            echo '<br><br>Destroying: ', $this->lieu, PHP_EOL;
          }

          //renvoie la valeur de lieu
         public function getLieu(){
          return $this->lieu;
        }

          //renvoie la valeur de image
         public function getAdresse(){
          return $this->adresse;
        }

          //renvoie la valeur de ville
         public function getVille(){
          return $this->ville;
        }         

         //renvoie la valeur de birthday
         public function getTelephone(){
          return $this->telephone;
        }

        //renvoie la valeur de horaire
        public function getHoraires_mardi_samedi_debut(){
          return $this->horaires_mardi_samedi_debut;
        }

        //renvoie la valeur de horaire
        public function getHoraires_mardi_samedi_fin(){
          return $this->horaires_mardi_samedi_fin;
        }

        //renvoie la valeur de horaire
        public function getHoraires_dimanche_debut(){
          return $this->horaires_dimanche_debut;
        }

        //renvoie la valeur de horaire
        public function getHoraires_dimanche_fin(){
          return $this->horaires_dimanche_fin;
        }


          //renvoie la valeur de listefleur
          public function getFleur(){
            return $this->Fleur;
       }


              //modifie la valeur du lieu avec $val
              public function setLieu(string $val=""){
                if($val!=null) $this->lieu = $val;
                else die("le lieu est obligatoire");
              }

              //modifie la valeur du image avec $val
              public function setAdresse(string $val=""){
                if($val!=null) $this->adresse = $val;
                else die("l'adresse doit exister");
              }


              //modifie la valeur ville avec $val
              public function setVille(string $val=""){
                $this->ville = $val;
              }


              //modifie la valeur du telephone avec $val
              public function setTelephone($val=""){
                if($val>0)  $this->telephone = $val;
                else die("le telephone ne peut pas être négatif");
              }


              //modifie la valeur du telephone avec $val
              public function setHoraires_mardi_samedi_debut($val=null){
                  if($val>0)  $this->horaires_mardi_samedi_debut = $val;
                  else die("horaires obligatoire");
                }

                //modifie la valeur du telephone avec $val
              public function setHoraires_mardi_samedi_fin($val=null){
                  if($val>0)  $this->horaires_mardi_samedi_fin = $val;
                  else die("horaires obligatoire");
                }

                //modifie la valeur du telephone avec $val
              public function setHoraires_dimanche_debut($val=null){
                  if($val>0)  $this->horaires_dimanche_debut = $val;
                  else die("horaires obligatoire");
                }

                //modifie la valeur du telephone avec $val
              public function setHoraires_dimanche_fin($val=null){
                  if($val>0)  $this->horaires_dimanche_fin = $val;
                  else die("horaires obligatoire");
                }

        //modifie la valeur de fleur avec $val
        public function setFleur(array $val=[]){
          if($val!=null) $this->Fleur = $val;
          else die("le nom de la fleur est necessaire");
        }
    }



    //liste fleur marche pas
?>