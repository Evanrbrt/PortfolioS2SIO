<?php


    /*
      class Plante
      une Plante se caractérise par un nom
    */
    class Plante{
        private string $nom_plantes;
        private string $image_plantes;
        private string $temperature_degres;
        private float $prix_plantes;

        // constructeur unifié permettant d'initialiser les variables d'instance
        public function __construct(string $p_nom="blox", string $p_image="", string $p_temperature="3", float $p_prix=null){

          if (empty($p_nom)) die("le nom de la Plante est obligatoire");

          // initialisation de la variable d'instance $nom
          $this->nom_plantes=$p_nom;

          if(!empty($p_image)) $this->image_plantes = $p_image;
          
          if(!empty($p_temperature)) $this->temperature_degres = $p_temperature;
          if (empty($p_temperature)) die("la temperature est obligatoire !");  

          // appeler imperativement les accesseurs s'il y en a.
          if(!empty($p_prix)) $this->setPrix($p_prix);

        }

          public function __destruct() {
            echo '<br><br>Destroying: ', $this->nom_plantes, PHP_EOL;
          }

          //renvoie la valeur de nom
         public function getNom(){
          return $this->nom_plantes;
        }

          //renvoie la valeur de image
         public function getImage(){
          return $this->image_plantes;
        }

          //renvoie la valeur de temperature
         public function getTemperature(){
          return $this->temperature_degres;
        }         

         //renvoie la valeur de birthday
         public function getPrix(){
          return $this->prix_plantes;
        }


        //modifie la valeur du nom avec $val
        public function setNom(string $val=null){
          if($val!=null) $this->nom_plantes = $val;
          else die("le nom de la plante est obligatoire");
        }

        //modifie la valeur du image avec $val
        public function setImage(string $val=null){
          if($val!=null) $this->image_plantes = $val;
          else die("l'image doit exister");
        }


        //modifie la valeur temperature avec $val
        public function setTemperature(string $val=null){
          $this->temperature_degres = $val;
        }


         //modifie la valeur du prix avec $val
         public function setPrix(float $val=null){
          if($val>0)  $this->prix_plantes = $val;
          else die("le prix d'une Plante ne peut pas être négatif");
        }
    }
?>