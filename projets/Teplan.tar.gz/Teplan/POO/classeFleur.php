<?php

    /*
      class Fleur
      une fleur se caractérise par un nom
    */
    class Fleur{
        private string $nom;
        private string $image;
        private Origine $origine;
        private float $prix;
        private $couleur=array();
        private Ensoleillement $ensoleillement;


        // constructeur unifié permettant d'initialiser les variables d'instance
        public function __construct(string $p_nomFleur="", string $p_image="", Origine $p_origine=null, float $p_prix=0, array $p_couleur=[], Ensoleillement $p_ensoleillement=null){

         

          // initialisation de la variable d'instance $nom
          $this->setNomFleur($p_nomFleur);
          $this->setImage($p_image);
          $this->setOrigine($p_origine);
          $this->setEnsoleillement($p_ensoleillement);
          $this->setPrix($p_prix);
          $this->setCouleur($p_couleur);

        }

        /*
        public function __destruct() {
            echo '<br><br>Destroying: ', $this->nom, PHP_EOL;
        }
        */
          //renvoie la valeur de nom
        public function getNomFleur(){
          return $this->NomFleur;
        }

          //renvoie la valeur de image
        public function getImage(){
          return $this->image;
        }

          //renvoie la valeur de origine
         public function getOrigine(){
          return $this->origine;
        }    
        
                  //renvoie la valeur de origine
                  public function getEnsoleillement(){
                    return $this->ensoleillement;
                  }         

         //renvoie la valeur de birthday
         public function getPrix(){
          return $this->prix;
        }

          //renvoie la valeur de couleur
           public function getCouleur(){
             return $this->couleur;
        }


        //modifie la valeur du nom avec $val
        public function setNomFleur(string $val=""){
          if(empty($val)) die("le nom est obligatoire");
          $this->nom = $val;
          
        }

        //modifie la valeur du image avec $val
        public function setImage(string $val=""){
          if($val!=null) $this->image = $val;
          else die("l'image doit exister");
        }


        //modifie la valeur origine avec $val
        public function setOrigine(Origine $val=null){
          $this->origine = $val;
        }

                //modifie la valeur origine avec $val
                public function setEnsoleillement(Ensoleillement $val=null){
                  $this->ensoleillement = $val;
                }


        //modifie la valeur du prix avec $val
        public function setPrix(float $val=null){
          if($val>0)  $this->prix = $val;
          else die("le prix d'une fleur ne peut pas être négatif");
        }

        //modifie la valeur de couleur avec $val
        public function setCouleur(array $val=[]){
          if($val!=null) $this->couleur = $val;
          else die("la couleur est necessaire");
        }
    }
?>