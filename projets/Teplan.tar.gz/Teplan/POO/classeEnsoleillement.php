<?php


    /*
      class ensoleillement
      une Plante se caractérise par un nom
    */
    class Ensoleillement{
        private string $nom_ensoleillement;
       

        // constructeur unifié permettant d'initialiser les variables d'instance
        public function __construct(string $p_ensoleillement=""){

         
          // initialisation de la variable d'instance $nom
          $this->setEnsoleillement($p_ensoleillement); 
        }

        /*
          public function __destruct() {
            echo '<br><br>Destroying: ', $this->nom_ensoleillement, PHP_EOL;
          }
          */

          //renvoie la valeur de nom
          public function getEnsoleillement(){
            return $this->nom_ensoleillement;
          }



                  //modifie la valeur du nom avec $val
        public function setEnsoleillement(string $val=""){
            if(empty($val)) die("le nom de l'ensoleillement est obligatoire");
            $this->nom_ensoleillement = $val;
             
          }
        }