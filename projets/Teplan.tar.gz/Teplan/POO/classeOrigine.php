<?php


    /*
      class Origine
      une Plante se caractérise par une origine
    */
    class Origine{
        private string $nom_origine;
       

        // constructeur unifié permettant d'initialiser les variables d'instance
        public function __construct(string $p_nom=""){

          if (empty($p_nom)) die("le nom de l'Origine est obligatoire");

          // initialisation de la variable d'instance $nom
          $this->setOrigine($p_nom); 

        }
        /*
          public function __destruct() {
            echo '<br><br>Destroying: ', $this->nom_origine, PHP_EOL;
          }
          */
          //renvoie la valeur de nom
          public function getOrigine(){
            return $this->nom_origine;
          }



                  //modifie la valeur du nom avec $val
        public function setOrigine(string $val=""){
            if($val!=null) $this->nom_origine = $val;
            else die("le nom de l'origine est obligatoire");
          }
        }

      