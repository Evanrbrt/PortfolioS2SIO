<?php


    /*
      class Couleur
      une Couleur se caractérise par un nom
    */
    class Couleur{
        private string $nom_couleur;
       
       

        // constructeur unifié permettant d'initialiser les variables d'instance
        public function __construct(string $p_couleur=""){

         

          // initialisation de la variable d'instance $nom
          
         $this->setCouleur($p_couleur);


        }
          /*
          public function __destruct() {
            echo '<br><br>Destroying: ', $this->nom_couleur, PHP_EOL;
          }
          */
          //renvoie la valeur de nom
          public function getCouleur(){
            return $this->nom_couleur;
            
          }


                  //modifie la valeur du nom avec $val
        public function setCouleur(string $val=""){
            if(empty($val)) die("la couleur est obligatoire");
            $this->nom_couleur=$val;
            }
      }