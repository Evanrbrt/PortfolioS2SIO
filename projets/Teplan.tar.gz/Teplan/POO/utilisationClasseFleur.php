<?php

    // inclusion de la classe Fleur, Accessoire, Couleur, Origine, Ensoleillement, Magasin

    include_once("classeOrigine.php");
    include_once("classeEnsoleillement.php");
    include_once("classeFleur.php");
    include_once("classePlante.php");
    include_once("classeCouleur.php");
    include_once("classeAccessoire.php");
    include_once("classeMagasin.php");
    

        //création de l'instace de fleur $Alstroemeria_jaune, tp3 travail 3 finit
        
        $fleurPleinsoleil = new Ensoleillement("plein soleil");
        $Chili = new Origine("chilienne");
        $Jaune = new Couleur("Jaune");
        $Noir = new Couleur("Noir");
         
        $Alstroemeria_jaune = new Fleur("Alstromeria Jaune", "../images/fleurs/alstroemeria-jaune-10-tiges.jpg", $Chili, 5,[$Jaune, $Noir],$fleurPleinsoleil);
        
        VAR_DUMP($Alstroemeria_jaune);



        $fleur_ombre = new Ensoleillement("ombrage");
        $Peru = new Origine("péruvienne");
        $Violet = new Couleur("violet");
        
        $Alstroemeria_violet = new Fleur("Alstromeria Violet", "../images/fleurs/alstroemeria-violet-10-tiges.jpg", $Peru, 15,[$Violet], $fleur_ombre);
        
        VAR_DUMP($Alstroemeria_violet);
        

        echo'test <br>';
        /*
        $lsFleur = new Fleur("Alstromeria Jaune");
        var_dump($lsFleur);

        $lsFleur2 = new Fleur("Alstromeria Violet");
        var_dump($lsFleur2);
        */



        $TEPLAN = new Magasin("Magasin Teplan", "8 rue de la Graine", "reims", "03 26 12 34 56", 10, 14, 10, 20, [$Alstroemeria_jaune, $Alstroemeria_violet]);

        VAR_DUMP($TEPLAN);

  
    

        //affichage de l'instace de fleur $Alstroemeria_jaune, TP 1
        
        echo "fleur =".$Alstroemeria_jaune->getNom()."<br>";
        echo 'image = <img src="'.$Alstroemeria_jaune->getImage().'" style="width:50px"><br>';
        echo "origine = <br>";
        echo "prix = ".$Alstroemeria_jaune->getPrix()." euros <br>";
        echo "<br> Les fleurs sont ".$Alstroemeria_jaune->getNom()." et ".$Alstromeria_violet->getNom().".";





    //création de l'instance fleur
    //avec valeurs par défaut
    /*
    $fleurvide = new Fleur();
    var_dump($fleurvide);



    //Test des erreurs//
   
    $bleu_color= new Couleur();
    $bleu_color->setCouleur();

    $chili_origine= new Origine();
    $chili_origine->setOrigine();
    
    $accessoire_pelle= new Accessoire();
    $accessoire_pelle->setNom();

    $bambou= new Plante();
    $bambou->setNom();

    $ensoleillement= new Ensoleillement();
    $ensoleillement->setNom();

    $magasin= new Magasin();
    $magasin->setLieu();
    


    //Test du constructeur avec die pour $nom
    
    $AlstroemeriaJaune = new Fleur();
    $Alstroemeria_jaune->setNom();

    // test du constructeur avec die pour $origine
    $Alstroemeria_jaune->setOrigine();
    */

    ?>