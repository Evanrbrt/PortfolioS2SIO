<?php


    /*
      class Accessoire
      une Accessoire se caractérise par un nom
    */
    class Accessoire{
        private string $nom_accessoires;
        private string $image_accessoires;
        private string $description_degres;
        private float $prix_accessoires;

        // constructeur unifié permettant d'initialiser les variables d'instance
        public function __construct(string $p_nom="blox", string $p_image="", string $p_description="h", float $p_prix=null){

          if (empty($p_nom)) die("le nom de l'accessoire est obligatoire");

          // initialisation de la variable d'instance $nom
          $this->nom_accessoires=$p_nom;

          if(!empty($p_image)) $this->image_accessoires = $p_image;
          
          if(!empty($p_description)) $this->description_degres = $p_description;
          if (empty($p_description)) die("la description est obligatoire !");  

          // appeler imperativement les accesseurs s'il y en a.
          if(!empty($p_prix)) $this->setPrix($p_prix);

        }

          public function __destruct() {
            echo '<br><br>Destroying: ', $this->nom_accessoires, PHP_EOL;
          }

          //renvoie la valeur de nom
         public function getNom(){
          return $this->nom_accessoires;
        }

          //renvoie la valeur de image
         public function getImage(){
          return $this->image_accessoires;
        }

          //renvoie la valeur de description
         public function getDescription(){
          return $this->description_degres;
        }         

         //renvoie la valeur de birthday
         public function getPrix(){
          return $this->prix_accessoires;
        }


        //modifie la valeur du nom avec $val
        public function setNom(string $val=null){
          if($val!=null) $this->nom_accessoires = $val;
          else die("le nom de l'accessoire est obligatoire");
        }

        //modifie la valeur du image avec $val
        public function setImage(string $val=null){
          if($val!=null) $this->image_accessoires = $val;
          else die("l'image doit exister");
        }


        //modifie la valeur description avec $val
        public function setDescription(string $val=null){
          $this->description_degres = $val;
        }


         //modifie la valeur du prix avec $val
         public function setPrix(float $val=null){
          if($val>0)  $this->prix_accessoires = $val;
          else die("le prix d'une Accessoire ne peut pas être négatif");
        }
    }
?>