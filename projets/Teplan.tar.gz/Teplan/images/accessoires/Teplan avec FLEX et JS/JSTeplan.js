

function InfoAlstroemeria() {

    alert("Information sur l'Alstroemeria jaune\ntempérature min : -15°C\nensoleillement : ensoleillée\norigine : Chilli")
}
