function coordonee() {

var co = document.getElementById("co");
                co.innerHTML += " Magasin Teplan<br>8 rue de la Graine<br>51100 REIMS<br>03.26.12.34.56";
    
}

