<?php
include_once("./myParam.inc.php");

function listePlantes(){

    $conn = pg_connect(' host= '.HOST.' dbname= '.DB.' user= '.USER.' password= '.PASS);

if (!$conn) {
    die("Erreur de connexion : " .
    pg_last_error()); 
}

//requête listePlantes

$sql="select image_plantes, prix_plantes, nom_plantes
      from plantes";

$result=pg_query($conn, $sql);

if(!$result){
    die("Erreur de connexion : " .
    pg_last_error()); 
}
$row=pg_fetch_array($result);

$texte = '';
while($row = pg_fetch_row($result)){

    $texte .= '<div id="Bambou">';
    $texte .= '<img src ='.$row[0].' >';
    $texte .= '<p>Bambou</p>';
    $texte .= '<p>'.$row[1].'€</p>';

    $texte .= ' </div>';

}

pg_free_result($result);
pg_close($conn);
return $texte;




}


?>