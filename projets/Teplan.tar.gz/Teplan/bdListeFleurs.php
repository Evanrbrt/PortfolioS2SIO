<?php
include_once("./myParam.inc.php");

function listeFleurs(){

    $conn = pg_connect(' host= '.HOST.' dbname= '.DB.' user= '.USER.' password= '.PASS);

if (!$conn) {
    die("Erreur de connexion : " .
    pg_last_error()); 
}

//requête listeFleurs

$sql="select image_fleurs, prix_fleurs, nom_fleurs
      from fleurs";

$result=pg_query($conn, $sql);

if(!$result){
    die("Erreur de connexion : " .
    pg_last_error()); 
}
$row=pg_fetch_array($result);

$texte = '';
while($row = pg_fetch_row($result)){
    $texte .= ' <div onclick="InfoAlstroemeria()" >';
    $texte .= '<img src ='.$row[0].' >';
    $texte .= '<p>'.$row[2].'</p>';
    $texte .= '<p>'.$row[1].'€</p>';

    $texte .= ' </div>';

}

pg_free_result($result);
pg_close($conn);
return $texte;

}




?>