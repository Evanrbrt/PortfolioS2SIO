<?php
define("HOST", "localhost");
define("USER", "erobert" );
define("DB", "bdteplan" );
define("PASS", " 1569Pepitot.");
?>
