<?php

echo'<html>
    <head>
        <title>TEPLAN</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Teplan.css">
        <script src="JSTeplan.js"></script>
    </head>
    <body>


	
				
				<script>
                
                
            </script>
            <FORM action ="mailto:estelle.gougelet@ac-reims.fr" ENCTYPE="text/plain">
            <label for="">Contact : </label><input type="text">
            
				<input type="submit" value="envoyer" >
				</FORM>


	</body>

</html>'
?>