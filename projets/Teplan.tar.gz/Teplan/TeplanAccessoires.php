<html>
    <head>
        <title>TEPLAN</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Teplan.css">
        <script src="JSTeplan.js"></script>
         <script src="footer.js"></script>
    </head>
    <body>
        <div id="MainPage4">
            <h1 id="TitreFleurs">Nos Accessoires - quelques produits</h1>
            <div Id="Accessoires">
                <div id="transplanter">
                    <img src="images/accessoires/transplanter.png">
                    <p>Transplanter</p>
                    <img src="images/accessoires/1.png">
                </div>

                <div id="trowel">
                    <img src="images/accessoires/trowel.png">
                    <p>trowel</p>
                    <img src="images/accessoires/2.png">
                </div>

                <div onclick="AccessoirePruner()" id="pruner">
                    <img src="images/accessoires/pruner.png">
                    <p>pruner</p>
                    <img src="images/accessoires/3.png">
                </div>

               
            </div>
            
            
            
                        <div Id="Accessoires">
                <div id="transplanter">
                    <img src="images/accessoires/rake.png">
                    <p>Rake</p>
                    <img src="images/accessoires/4.png">
                </div>

                <div id="trowel">
                    <img src="images/accessoires/weeder.png">
                    <p>weeder</p>
                    <img src="images/accessoires/5.png">
                </div>

                <div id="pruner">
                    <img src="images/accessoires/weeding fork.png">
                    <p>weeding fork</p>
                    <img src="images/accessoires/6.png">
                </div>

               
            </div>
            
            
        </div>
        
        <footer>
                 <?php
                    include_once("bdMagasin.php");

                    $texte = footer();
                    echo $texte;
                ?>  
            <nav class="Lien">
                <a href="TeplanAcceuil.php"><img class="Lien" src="images/planteAcceuil.png"></a>
                <a href="TeplanPlantes.php"><img class="Lien" src="images/plantePlantes.png"></a>
                <a href="TeplanFleurs.php"><img class="Lien" src="images/planteFleurs.png"></a>
            </nav>
        </footer>
    </body>

</html>
