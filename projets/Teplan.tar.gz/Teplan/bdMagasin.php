<?php
include_once("./myParam.inc.php");

function horaireMagasin(){

    $conn = pg_connect(' host= '.HOST.' dbname= '.DB.' user= '.USER.' password= '.PASS);

if (!$conn) {
    die("Erreur de connexion : " .
    pg_last_error()); 
}

//requête horaires magasin

$sql="select horaires_mardi_samedi_debut, horaires_mardi_samedi_fin, horaire_dimanche_debut, horaire_dimanche_fin
from magasin";
$result=pg_query($conn, $sql);
if(!$result){
    die("Erreur de connexion : " .
    pg_last_error()); 
}
$row=pg_fetch_array($result);

    $texte='<script>';
        $texte.= 'var MardiSamediOuverture = "'.$row['horaires_mardi_samedi_debut'].'";';
        $texte.= 'var MardiSamediFermeture = "'.$row['horaires_mardi_samedi_fin'].'";';
        $texte.= 'var DimancheOverture = "'.$row['horaire_dimanche_debut'].'";';
        $texte.= 'var DimancheFermeture = "'.$row['horaire_dimanche_fin'].'";';
        $texte.='</script>';

    return $texte;

}




function footer(){

    $conn = pg_connect(' host= '.HOST.' dbname= '.DB.' user= '.USER.' password= '.PASS);

if (!$conn) {
    die("Erreur de connexion : " .
    pg_last_error()); 
}

//requête horaires magasin

$sql="select lieu, adresse, code_postal, ville, telephone
from magasin";
$result=pg_query($conn, $sql);
if(!$result){
    die("Erreur de connexion : " .
    pg_last_error()); 
}
$row=pg_fetch_array($result);

$texte = '<div class="Contact">';
$texte.= '<div>';
$texte.= '<p>Magasin Teplan</p>';

$texte.= '<p>'.$row['adresse'].'</p>';
$texte.= '<p>'.$row['code_postal'].'</p>';
$texte.= '<p>'.$row["ville"].'</p>';

$texte.= '<div class="tel">';
$texte.= '<div class="telImg">';
$texte.= '<img id="Telephone"src="images/telephone.png"/>';
$texte.= '</div> ';
$texte.= '<div class="telTexte">';
$texte.= '<p class="texte">'.$row['telephone'].'</p>';
$texte.= '</div>';
$texte.= '</div>';
$texte.= '</div>';
$texte.= '</div>';



return $texte;

}

?>