
<html>
    <head>
        <title>TEPLAN</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="Teplan.css">
        <script src="JSTeplan.js"></script>
        <script src="footer.js"></script>

      
    </head>
    <body>
        <div id="MainPage3">
            <h1 id="TitreFleurs">Nos fleurs - quelques produits</h1>

                <FORM action ="" ENCTYPE="text/plain">
                <label for="">Ajouter une fleur : </label><input type="text">
				<input type="submit" value="envoyer" onclick="f_inserelesfleurs()">
				</FORM>

            <div Id="Fleurs">
               
            <?php
                include_once("bdListeFleurs.php");

                $texte = listeFleurs();
                echo $texte;
            ?>  

            </div>
        </div>
        
        <footer>
                <?php
                    include_once("bdMagasin.php");

                    $texte = footer();
                    echo $texte;
                ?>  
            <nav class="Lien">
                <a href="TeplanAcceuil.php"><img class="Lien" src="images/planteAcceuil.png"></a>
                <a href="TeplanPlantes.php"><img class="Lien" src="images/plantePlantes.png"></a>
                <a href="TeplanFleurs.php"><img class="Lien" src="images/planteFleurs.png"></a>
                <a href="TeplanAccessoires.php"><img class="Lien" src="images/accessoiresJ.jpg"></a>
            </nav>
        </footer>
    </body>

</html>'
