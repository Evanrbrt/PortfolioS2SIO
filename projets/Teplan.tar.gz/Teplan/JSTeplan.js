
function InfoAlstroemeria() {

    alert("Information sur l'Alstroemeria jaune\ntempérature min : -15°C\nensoleillement : ensoleillée\norigine : Chilli")
}





function AccessoirePruner() {

    alert("Information sur le pruner \nSécateur : outil d'agriculteur\n")
}
